Desktop Beomgyu character assets

Standing: beomgyu-standing.png
Celebrate: beomgyu-celebrate.png
Walk: six-pose 3-column, 2-row sprite sheet, row-major; faces right.
Run: run-0.png and run-1.png; faces left.
Hug: 20 transparent PNG frames from the original GIF, no face redraw. Play sequentially using delays in hug-frames/frames.json (milliseconds), then loop.

Walk/run and standing/celebration images were AI-assisted photo edits; hug frames use background masking of original pixels. Fan-made prototype; reference images belong to their respective owners.
